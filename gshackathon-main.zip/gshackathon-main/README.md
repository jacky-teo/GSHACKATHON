# gshackathon
This project is built using the flask framework. Kindly install the following libraries before deploying the project locally.

Library requirements:
Flask < pip install flask>
Pandas < pip install pandas>
Requests < pip install requests>
JSON 
Plotly <pip install plotly>
Ploly.express <pip install plotly.express>
Kaleido <pip install kaleido>

To deploy the web page, kindly open “main.py” via your IDE and run the script. The script will give you an IP address and from there your webpage is deployed. Paste the IP address in your browser to view the web page.

Please allow for some time for the web pages to load, thank you!
